const userRoles={
    ADMIN:"ADMIN",
    USER:"USER",
    MANAGER:"MANAGER"
}
module.exports=userRoles;